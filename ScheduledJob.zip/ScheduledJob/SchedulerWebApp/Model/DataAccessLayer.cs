﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
#endregion

namespace SchedulerWebApp.Model
{
    public abstract class DataAccessLayer
    {
        #region Methods & Propertices 
        public static string baseUrl { get; set; }
        public abstract bool GetEmailAddressFromDB();
        public abstract bool UpdateIsLinkCliked(int ID);
        #endregion
    }
}