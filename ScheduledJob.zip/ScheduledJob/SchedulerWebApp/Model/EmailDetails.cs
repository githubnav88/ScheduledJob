﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
#endregion

namespace SchedulerWebApp.Model
{
    // Email Details Model
    public class EmailDetails
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailID { get; set; }
        public string Subject { get; set; }
        public bool isClickedLink { get; set; }
        public string ID { get; set; }
        public string EmailBody { get; set; }
    }
}