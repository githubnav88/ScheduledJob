﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;
#endregion

namespace SchedulerWebApp.Model
{
    public class BusinessAccessLayer : DataAccessLayer
    {
        // Get the connection string 
        #region Variables 
        static string connectString = ConfigurationManager.AppSettings["ConnectionString"];
        static string SendGridAPI = ConfigurationManager.AppSettings["SendGridAPI"];
        static string SendGridMailFrom = ConfigurationManager.AppSettings["SendGridMailFrom"];
        SqlConnection con;
        static string _baseUrl;
        #endregion

        // Get all the Email ID's from tha database, which are not clicked / opend yet
        #region Get Email Address From DataBase
        public override bool GetEmailAddressFromDB()
        {
            _baseUrl = baseUrl; 

            bool isEmailSend = true;
            try
            {
                con = new SqlConnection(connectString);
                SqlCommand command = new SqlCommand("GetAllEmailAddress", con);
                command.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    EmailDetails email;

                    foreach (DataRow dr in dt.Rows)
                    {
                        email = new EmailDetails();
                        email.FirstName = dr["FirstName"].ToString();
                        email.LastName = dr["LastName"].ToString();
                        email.EmailID = dr["EmailID"].ToString();
                        email.ID = dr["ID"].ToString();
                        email.Subject = "<strong>Welcome to Activation Email</strong>";
                        email.EmailBody =  "Hello " + email.FirstName + " " + email.LastName + ",";
                        email.EmailBody += "<br /><br />Please click the following link to activate your account";
                        email.EmailBody += "<br /><a href = '" + _baseUrl + "ThankYouPage.aspx?ID=" + email.ID + "'>Click here to activate your account.</a>";
                        email.EmailBody += "<br /><br />Thanks";
                        // Email Sending  Mail Sending ..... 
                        SendGridMailSend(email);
                    }
                }

                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
            }

            return isEmailSend;
        }
        #endregion

        // Update Is Link Cliked 
        #region Update Is Link Cliked 
        public override bool UpdateIsLinkCliked(int ID) 
        {
            bool isEmailSend = true;
            try
            {
                con = new SqlConnection(connectString); 
                SqlCommand cmd = new SqlCommand("sp_UpdateIsLinkClicked", con);
                cmd.Parameters.AddWithValue("@ID", ID);
                cmd.Parameters.Add("@EmailID", SqlDbType.NVarChar, 50);
                cmd.Parameters["@EmailID"].Direction = ParameterDirection.Output;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();               
                if (cmd.ExecuteNonQuery() > 0)
                {
                    // Email Sending  = Thank Email Sending.....
                    EmailDetails email = new EmailDetails();
                    email.EmailID = (string)cmd.Parameters["@EmailID"].Value; 
                    email.Subject = "<strong>Thank You</strong>";
                    email.EmailBody = "<strong>Thank You for everything....</strong>";
                    // Email Sending = Mail Sending ..... 
                    SendGridMailSend(email);
                } 
                con.Dispose();
                con.Close();
            }
            catch (Exception ex) 
            { 
                con.Close();
                isEmailSend = false;
            }

            return isEmailSend;
        }
        #endregion 

        // Email Sending  Mail Sending .....
        #region Email Sending  Mail Send
        public void SendGridMailSend(EmailDetails email)
        {
            using (MailMessage mm = new MailMessage(ConfigurationManager.AppSettings["FromEmail"], email.EmailID))
            {
                mm.Subject = email.Subject;
                mm.Body = email.EmailBody;
                mm.IsBodyHtml = false;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = ConfigurationManager.AppSettings["Host"];
                smtp.EnableSsl = true;
                NetworkCredential NetworkCred = new NetworkCredential(ConfigurationManager.AppSettings["Username"], ConfigurationManager.AppSettings["Password"]);
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = int.Parse(ConfigurationManager.AppSettings["Port"]);
                smtp.Send(mm); 
                // Waiting Time
                System.Threading.Thread.Sleep(3000); 
            }
        }
        #endregion
    }
}