﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using SchedulerWebApp;
#endregion

namespace SchedulerWebApp
{ 
    public class Global : System.Web.HttpApplication
    {
        /// <summary>
        /// It will the first event, which will call first
        /// </summary>

        #region Application_Start
        protected void Application_Start(object sender, EventArgs e)
        {
            // We run our internal scheduler here 
            Scheduler.StartExceuting();
        }
        #endregion    
    }
}