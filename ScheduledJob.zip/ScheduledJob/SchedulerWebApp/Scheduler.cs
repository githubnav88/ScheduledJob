﻿#region Namespaces
using SchedulerWebApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
#endregion

namespace SchedulerWebApp
{
    public class Scheduler
    {
        /// <summary>
        ///  Start Exceuting Process
        /// </summary>
        /// 

        #region StartExceuting .....
        public static void StartExceuting()
        {
            // For Interval in Seconds 
            // This Scheduler will start at 23:00 and call after every 24 Hours
            // IntervalInDays(start_hour, start_minute, hours)
            MyScheduler.IntervalInDays(23, 00, 1, () =>
            {
                // Email Sending........
                DataAccessLayer dal = new BusinessAccessLayer();
                dal.GetEmailAddressFromDB();
            });
        }
        #endregion       
    }
}