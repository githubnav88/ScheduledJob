﻿#region Namespaces
using SchedulerWebApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
#endregion

namespace SchedulerWebApp
{
    public partial class ThankYouPage : System.Web.UI.Page
    {
        #region All Events Here 
        // On Page Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {                
                if(!string.IsNullOrEmpty(Request.QueryString["ID"]))
                {
                    int getID = Convert.ToInt32(Request.QueryString["ID"]);

                    // Update Table, isLinkCliked set true
                    DataAccessLayer dal = new BusinessAccessLayer();
                    dal.UpdateIsLinkCliked(getID);                     
                }
            }
        }
        #endregion
    }
}